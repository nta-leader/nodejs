Chiếc di động kia hẳn là mới bỏ lại chưa lâu, tôi vừa nhặt lên liền thấy ngay vệt máu loãng dính trên đó, tức thì có linh cảm không lành: “Xem ra nơi này còn một nhóm khác, hơn nữa hình như có người bị thương. Điện thoại làm sao từ trên trời rơi xuống được?”

Tôi mở nắp máy, trên màn hình có mấy dãy số liền nhau đều là số điện thoại ngoại quốc, ngoài ra cũng không thu được thêm thông tin gì. Chú Ba nói: “Dù thế nào chúng ta cũng không thể đi tìm họ, trước mắt cứ lên đường đã.” Tôi xem xét bốn phía chẳng có chút manh mối, đành phải mở đường tiếp tục đi. Tuy vậy, giữa vùng hoang sơn dã lĩnh lại bắt gặp một thứ đồ từ thế giới văn minh vẫn cảm thấy thật khó tưởng tượng. Tôi lên tiếng hỏi lão già kia, ngoài chúng tôi ra có ai khác tiến vào khu rừng này hay không.

Lão cười hề hề đáp: “Cách đây hai tuần có một toán khoảng trên mười người, đến nay vẫn chưa thấy trở ra. Nơi đây rất nguy hiểm, các vị, giờ quay lại vẫn còn kịp đó.”

“Cứ cho là có yêu ma quỷ quái thì đã sao?” Đại Khuê nói “Nói cho ông biết, cương thi ngàn năm gặp anh chàng này của chúng tôi còn phải phục xuống dập đầu, có hắn ở đây thì yêu quái nhằm nhò gì, đúng không?” Hắn hỏi Muộn Du Bình, Muộn Du Bình không có chút phản ứng, như thể xem lời hắn nói là không khí vậy. Đại Khuê như đụng phải gai, bực tức cũng chẳng làm gì được.

Chúng tôi lặng lẽ đi tiếp. Chưa đến bốn giờ chiều mà đất trời đã tối tăm mù mịt, rốt cuộc cũng đến nơi cần đến.

Thứ đầu tiên đập vào mắt là mười mấy chiếc lều trại quân dụng hầu như còn nguyên vẹn. Đây là loại lều chất lượng cực kỳ tốt, tuy trên nóc phủ đầy lá rụng đang mục nát nhưng bên trong khô ráo sạch sẽ, ngoài ra còn có không ít vật dụng thông thường. Chúng tôi cứ tùy tiện xem xét, xung quanh rải rác vô số vũ khí quân trang nhưng hoàn toàn không có thi thể, ông già kia chưa hẳn đã nói dối.

Thậm chí chúng tôi còn tìm được cả một chiếc máy phát điện cùng mấy ống đựng xăng, tuy động cơ đã được tra dầu nhưng phần lớn linh kiện đều rơi vào tình trạng rỉ sét. Bàn Khuê thử khởi động thì không có chút động tĩnh gì, chỉ có xăng vẫn ok. Tôi thử lật đi lật lại, phát hiện ra tất cả đồ đạc đều bị xé nhãn, ngay cả nhãn hiệu lều trại và ba lô của bọn họ cũng trống trơn, thật là kỳ quái. Có vẻ như, những người này một mực không muốn kẻ khác lần ra lai lịch của họ.

Chúng tôi ở lại doanh địa đó nhóm lửa rồi ăn qua quýt một bữa cơm chiều. Lão già vừa ăn vừa mắt la mày lét cảnh giác nhìn bốn phía như thể sợ yêu quái sẽ đột nhiên xông vào mà treo cổ lão lên vậy. Mấy thứ đồ ăn đóng hộp, thực lòng mà nói vô cùng khó nuốt, tôi hầu như chỉ uống vài ngụm nước cho qua bữa.

Muộn Du Bình vừa ăn vừa xem bản đồ, hắn chỉ vào một địa điểm có vẽ hình mặt hồ ly quái dị trên đó: “Hiện giờ chắc chắn chúng ta đang ở đây.”

Sau khi chúng tôi đã nhìn rõ, hắn nói tiếp: “Chỗ này là nơi cúng tế, phía dưới hẳn là đài cúng tế. Những đồ bồi táng có lẽ ở ngay đây thôi.”

Chú Ba ngồi xổm trên mặt đất vốc một nắm đất đưa lên mũi ngửi qua, lắc đầu rồi tiến vài bước, lại xem xét rồi nói: “Chôn sâu quá, lấy xẻng cắm xuống thử xem.”

Chúng tôi lấy ống thép có rãnh xoáy ra lắp lưỡi xẻng vào, chú Ba lấy chân vạch mấy vệt trên mặt đất đánh dấu vị trí cần đào. Đại Khuê đầu tiên cố định đầu xẻng, sau đó lấy búa cán ngắn gõ lên, xẻng bắt đầu lún sâu xuống đất. Chú Ba đặt một bàn tay lên cán xẻng để cảm nhận tình hình bên dưới. Khi gõ đến ống thứ mười ba, chú đột nhiên nói: “Đủ rồi!”

Chúng tôi rút dần từng khúc từng khúc cán xẻng, cuối cùng cũng lấy được một ít đất. Đại Khuê tháo lưỡi xẻng ra mang đến gần đống lửa cho chúng tôi nhìn rõ. Tôi và chú Ba vừa thấy, tức thì mặt mũi đều tái đi, ngay cả Muộn Du Bình cũng “a” lên một tiếng. Hóa ra thứ đất kia giống như thấm đẫm máu, giờ đang tí tách rỉ ra thứ chất lỏng y hệt máu tươi.

Chú Ba ngửi(*) thử rồi nhíu mày. Tôi và chú Ba đã từng xem qua ghi chép về huyết thi, nhưng tình hình cụ thể thế nào, chỉ dựa vào bút ký của ông nội tôi thì không thể suy đoán được một cách chuẩn xác. Nhưng có một điều chắc chắn, nếu bùn đất ngấm máu thế kia thì dưới mộ chắc chắn đầy những bất trắc.

(*) Người ta dùng xẻng sắt xiên xuống đất rồi ngửi các thứ mùi để xác định thành phần đất, còn xẻng Lạc Dương khi xiên xuống mang đất lên chỉ cần dùng mắt cũng đủ quan sát được các thành phần thổ nhưỡng. Do chất đất ở đây quá bất thường nên mới phải ngửi, còn cơ bản, ở đây vẫn dùng xẻng Lạc Dương.

Tôi nhìn chú Ba chờ xem chú quyết định thế nào. Chú ngẫm nghĩ một hồi, châm một điếu thuốc rồi nói: “Mặc kệ đi, cứ đào ra rồi tính.”

Bên kia, Phan Tử và Đại Khuê cũng không ngừng tay, Đại Khuê sục xẻng xuống mấy lần đều đưa lưỡi xẻng cho chú Ba. Chú Ba ngửi thử từng lưỡi một, sau đó dùng bay nối liền những điểm cắm xẻng vào nhau. Tôi đứng nhìn họ bận rộn định vị, cuối cùng trên mặt đất dần hiện ra hình dạng sơ lược của cổ mộ.

Dò tìm vị trí mộ huyệt là kiến thức cơ bản của dân trộm mộ, có thể nói, đồ hình trên mặt đất thế nào, mộ bên dưới chắc chắn giống y như vậy, rất ít người tính toán sai, nhưng tôi xem qua cấu trúc này âm thầm cảm thấy có điều không ổn. Hầu như toàn bộ cổ mộ thời Chiến quốc không có địa cung, nhưng lăng mộ bên dưới này rõ ràng là có, hơn nữa nóc mộ còn xây bằng gạch, không bình thường chút nào.

Chú Ba đưa mấy ngón tay tỉ mỉ đo đạc, cuối cùng chỉ vào vị trí hạ quan tài vừa xác định được, nói: “Bên dưới đã là đỉnh mộ, không thể đâm xẻng xuống được nữa, thôi thì chỉ xác định được vị trí đại khái. Cái địa cung này rất quái, ta chẳng có tí kiến thức nào cả, đành dựa theo cổ mộ thời Tống, đào vào từ tường hậu. Nếu không được còn tìm cách khác, nhanh tay nhanh chân lên một chút!”

Mấy người chú Ba đã đi đào hầm trộm mộ dễ đến mười mấy năm, tốc độ như điện, mấy lưỡi xẻng nhấc lên hạ xuống như gió cuốn, trong chốc lát đã đào được cái động sâu tầm bảy tám mét. Đây vốn là vùng hoang dã, đất đai chẳng phải của ai, chúng tôi cứ thế xúc bùn ra. Lát sau đã nghe Đại Khuê gào lên phía bên dưới: “Quá chuẩn!”

Hang Đại Khuê đào rất lớn, gần như thủng hẳn một mảng tường mộ. Chúng tôi bật đèn mỏ soi vào bên trong, Muộn Du Bình thấy Đại Khuê tay chân khua loạn vào vách tường vội vã ngăn lại: “Đừng có chạm vào cái gì hết!”. Ánh mắt Muộn Du Bình sắc như dao tức khắc khiến Đại Khuê sợ đến nhảy dựng lên.

Hắn vươn hai ngón tay đặt lên mặt tường, chậm rãi lần theo từng kẽ gạch, một lúc lâu sau mới dừng lại mà nói: “Nơi này có tường kép chống trộm. Muốn trộm, phải lôi từng viên gạch ra. Không thể đẩy vào, phá lại càng không được.”

Phan Tử sờ sờ tường, thốt lên: “Sao có thể như thế được, ngay cả kẽ hở cũng không có? Thế này thì lôi gạch ra kiểu gì?”

Muộn Du Bình cẩn thận quan sát một lúc, hắn chạm vào một viên gạch, đột ngột tăng lực trên tay rút viên gạch đó ra khỏi vách tường. Gạch xây chắc chắn như vậy, chỉ dùng tay không mà rút cả viên gạch, chẳng hiểu hắn phải dùng đến bao nhiêu sức lực nữa. Hai ngón tay của hắn quả nhiên không tầm thường chút nào.

Hắn cẩn thận đặt viên gạch xuống đất, chỉ vào mặt sau. Chúng tôi chụm đầu vào nhìn, trông thấy rõ ràng một lớp sáp đỏ sậm.

“Những lớp tường này khi xây đều sử dụng a-xít, khi phá tường, chỉ cần chúng ta mạnh tay một chút, thứ a-xít này sẽ bắn vào người đến cháy thịt cháy da.”

Tôi nuốt nước bọt, đột nhiên nghĩ tới con quái vật tượt da mà ông nội đã nhìn thấy. Không lẽ đó không phải huyết thi, mà chính là ông cố bị đổ a-xít lên người? Không lẽ những phát súng mà ông nội bắn, chính là bắn vào ông cố?

Muộn Du Bình bảo Bàn Khuê đào một cái hố nhỏ sâu chừng năm thước rồi lấy trong túi ra một đầu kim tiêm cùng ống nhựa dẻo, cắm kim vào ống sau đó đem thả đầu kia vào hố. Phan Tử thổi ống giữ lửa (1) đốt đỏ đầu kim lên, Muộn Du Bình cẩn thận cắm ngập đầu kim vào lớp sáp trên tường. Ngay lập tức, a-xít đỏ rực theo đường ống chảy xuống hố đã được đào sẵn.

Không bao lâu, lớp sáp đỏ đã chuyển sang màu trắng toát, hình như còn có thứ gì đó lấp lánh. Muộn Du Bình gật gật đầu: “Được rồi.” Chúng tôi tức thì bắt tay vào đào. Chẳng mấy chốc, một hang động đủ cho một người chui qua đã hiện ra trên vách tường. Chú Ba thổi lửa soi vào động, theo ánh lửa mà quan sát bên trong.

Chúng tôi tiến vào từ hướng Bắc, vừa đi vừa nhìn ngó xung quanh. Trên mặt đất lát bằng toàn những phiến đá tảng, bên trên khắc chi chít văn tự cổ đại. Những phiến đá này đều được sắp xếp theo phương vị bát quái, bên ngoài là tảng to, càng vào bên trong càng nhỏ. Bốn phía huyệt mộ là tám ngọn Trường minh đăng(2), tất nhiên đều đã tắt ngóm từ lâu. Giữa huyệt bày một chiếc đỉnh vuông bốn chân, trên có biểu tượng mặt trăng, mặt trời và các vì sao. Phía Nam mộ thất, ngay hướng đối diện chúng tôi đặt một quan tài đá. Phía sau quan tài là một lối đi, hình như là hướng xuống dưới, không rõ nó dẫn đến nơi quái quỷ nào nữa.

Chú Ba bước tới nghe ngóng thăm dò, sau đó vẫy vẫy tay, chúng tôi lần lượt từng người chui vào.

Chú nhìn những văn tự chằng chịt trên mặt đất, quay sang hỏi Muộn Du Bình: “Tiểu Ca, cậu xem những chữ này, liệu có luận ra được nơi đây mai táng người nào không?”

Muộn Du Bình lắc đầu không nói gì.

Chúng tôi châm lửa thắp vào Trường minh đăng, cả mộ thất tức khắc sáng bừng lên. Tôi lại liên tưởng đến con quái vật trong bút ký của ông nội, hình như…ông còn nhiều lần nhắc đến việc nghe thấy tiếng cười kèng kẹc, nghĩ đến đây tôi bất giác sợ run lên. Phan Tử bước đến gần cái đỉnh, nghiêng đầu ngó vào xem có gì bên trong. Đột nhiên, hắn hô lên một tiếng: “Lão Ba, ở đây có báu vật!”

Chúng tôi đều tiến lên xem, thấy ngay một cái xác không đầu khô quắt, quần áo đã rữa nát hết, trên người nó có vài món trang sức bằng ngọc. Gã Phan Tử làm ẩu không thèm nể mặt người chết, thẳng tay giật khối ngọc xuống.

“Chắc đây là thân thể của người theo bồi táng ở thế giới bên kia. Họ chặt đầu tế trời, sau đó mang xác đến đây tế người. Kẻ này có lẽ là tù binh, thân phận nô lệ làm sao có được thứ trang sức kia.”

Phan Tử đột ngột co chân nhảy vào trong đỉnh để mò mẫm thêm bảo vật, Muộn Du Bình muốn ngăn cũng không kịp, chỉ còn biết quay đầu lại cảnh giác nhìn chiếc quan tài đá, cũng may nó vẫn im lìm không có động tĩnh gì. Chú Ba quát loạn: “Thằng kia, đỉnh này là đồ đựng tế phẩm người ta dùng để cúng bái cho tổ tiên, cái thằng oắt nhà mày muốn thành tế phẩm hay sao?!”

Phan Tử cười ha hả: “Lão Ba, tôi đây đâu phải Đại Khuê, đừng có dọa tôi.” Hắn lấy thêm một cái bình ngọc lớn: “Ông nhìn đi, toàn những thứ thượng hạng, theo tôi chúng ta đổ quách cái đỉnh này ra xem bên trong còn có những gì…”

“Đừng có làm bậy, mày vác xác ra ngay đi!” Chú Ba nói, lo lắng nhìn sắc mặt Muộn Du Bình lúc này đã tái đi, ánh mắt gắt gao dán chặt vào quan tài đá như thể biết chắc sẽ có chuyện chẳng lành.

Đúng lúc đó, tôi chợt nghe một tiếng cười khành khạch. Tôi quay đầu, xương sống một đợt gai lạnh. Tiếng cười kia không phát ra từ quan tài, mà chính là từ Muộn Du Bình vọng lại.

—————————————-

Chú thích

(1) Nguyên văn: Hỏa chiết tử. Bộ dụng cụ lấy lửa thời xưa gồm que đánh lửa, đá lửa và ống giữ lửa. Trong đó ống giữ lửa rất tiện dụng, là một ống đựng mồi lửa có thể đem theo bên mình, khi cần có thể rút ra châm lửa hoặc dùng thay cho đuốc thắp sáng. Phương pháp làm ống giữ lửa là lấy dây khoai trắng hoặc tím ngâm trong nước cho nở, vớt ra đập dập, lại ngâm chung thêm với bông vải, bông lau vớt ra đập dập, phơi khô, trộn thêm các loại vật liệu dễ cháy như kali, lưu huỳnh, nhựa thông, long não chế thành. Xong xuôi bện lại thành dây thừng hoặc buộc thành hình ống dài nén vào ống trúc, châm lửa cho cháy ngún rồi đậy kín lại, lúc cần dùng rút nắp ra là cháy, rất dễ cháy, là loại vua chúa hoặc nhà có tiền sử dụng. Nhà bình thường có thể dùng các loại giấy cắt thành dạng dài hơn ống trúc, cuộn đều tay, nhét vào trong ống. Sau đó châm lửa, rồi đậy nắp thông gió lại, tàn lửa sẽ được giữ trong ống. Lúc cần dùng bật nắp, thổi nhè nhẹ để lửa cháy lên, khi thổi cần phải có kỹ thuật thì lửa mới cháy lên được.

Đây là mô tả trên baidu, tả ống giữ lửa thời phong kiến, mình nghĩ loại dùng trong truyện là loại có tẩm vật liệu dễ cháy, chỉ cần rút nắp ra để tàn lửa âm ỉ trong ống tiếp xúc với oxy là lửa sẽ lập tức bùng lên.

Hình:

(1) Trường minh đăng:

长明灯

Đèn thắp để thờ cúng, là loại đèn không thể thổi tắt mà qua một thời gian sẽ tự tắt, còn có tên khác là Minh đăng, hoặc Vô tận đăng. Lăng mộ vua chúa Trung Hoa cũng đặt Trường minh đăng với hi vọng lăng mộ sáng tỏ huy hoàng như cung điện lúc sinh thời

Chiếc di động kia hẳn là mới bỏ lại chưa lâu, tôi vừa nhặt lên liền thấy ngay vệt máu loãng dính trên đó, tức thì có linh cảm không lành: “Xem ra nơi này còn một nhóm khác, hơn nữa hình như có người bị thương. Điện thoại làm sao từ trên trời rơi xuống được?”

Tôi mở nắp máy, trên màn hình có mấy dãy số liền nhau đều là số điện thoại ngoại quốc, ngoài ra cũng không thu được thêm thông tin gì. Chú Ba nói: “Dù thế nào chúng ta cũng không thể đi tìm họ, trước mắt cứ lên đường đã.” Tôi xem xét bốn phía chẳng có chút manh mối, đành phải mở đường tiếp tục đi. Tuy vậy, giữa vùng hoang sơn dã lĩnh lại bắt gặp một thứ đồ từ thế giới văn minh vẫn cảm thấy thật khó tưởng tượng. Tôi lên tiếng hỏi lão già kia, ngoài chúng tôi ra có ai khác tiến vào khu rừng này hay không.

Lão cười hề hề đáp: “Cách đây hai tuần có một toán khoảng trên mười người, đến nay vẫn chưa thấy trở ra. Nơi đây rất nguy hiểm, các vị, giờ quay lại vẫn còn kịp đó.”

“Cứ cho là có yêu ma quỷ quái thì đã sao?” Đại Khuê nói “Nói cho ông biết, cương thi ngàn năm gặp anh chàng này của chúng tôi còn phải phục xuống dập đầu, có hắn ở đây thì yêu quái nhằm nhò gì, đúng không?” Hắn hỏi Muộn Du Bình, Muộn Du Bình không có chút phản ứng, như thể xem lời hắn nói là không khí vậy. Đại Khuê như đụng phải gai, bực tức cũng chẳng làm gì được.

Chúng tôi lặng lẽ đi tiếp. Chưa đến bốn giờ chiều mà đất trời đã tối tăm mù mịt, rốt cuộc cũng đến nơi cần đến.

Thứ đầu tiên đập vào mắt là mười mấy chiếc lều trại quân dụng hầu như còn nguyên vẹn. Đây là loại lều chất lượng cực kỳ tốt, tuy trên nóc phủ đầy lá rụng đang mục nát nhưng bên trong khô ráo sạch sẽ, ngoài ra còn có không ít vật dụng thông thường. Chúng tôi cứ tùy tiện xem xét, xung quanh rải rác vô số vũ khí quân trang nhưng hoàn toàn không có thi thể, ông già kia chưa hẳn đã nói dối.

Thậm chí chúng tôi còn tìm được cả một chiếc máy phát điện cùng mấy ống đựng xăng, tuy động cơ đã được tra dầu nhưng phần lớn linh kiện đều rơi vào tình trạng rỉ sét. Bàn Khuê thử khởi động thì không có chút động tĩnh gì, chỉ có xăng vẫn ok. Tôi thử lật đi lật lại, phát hiện ra tất cả đồ đạc đều bị xé nhãn, ngay cả nhãn hiệu lều trại và ba lô của bọn họ cũng trống trơn, thật là kỳ quái. Có vẻ như, những người này một mực không muốn kẻ khác lần ra lai lịch của họ.

Chúng tôi ở lại doanh địa đó nhóm lửa rồi ăn qua quýt một bữa cơm chiều. Lão già vừa ăn vừa mắt la mày lét cảnh giác nhìn bốn phía như thể sợ yêu quái sẽ đột nhiên xông vào mà treo cổ lão lên vậy. Mấy thứ đồ ăn đóng hộp, thực lòng mà nói vô cùng khó nuốt, tôi hầu như chỉ uống vài ngụm nước cho qua bữa.

Muộn Du Bình vừa ăn vừa xem bản đồ, hắn chỉ vào một địa điểm có vẽ hình mặt hồ ly quái dị trên đó: “Hiện giờ chắc chắn chúng ta đang ở đây.”

Sau khi chúng tôi đã nhìn rõ, hắn nói tiếp: “Chỗ này là nơi cúng tế, phía dưới hẳn là đài cúng tế. Những đồ bồi táng có lẽ ở ngay đây thôi.”

Chú Ba ngồi xổm trên mặt đất vốc một nắm đất đưa lên mũi ngửi qua, lắc đầu rồi tiến vài bước, lại xem xét rồi nói: “Chôn sâu quá, lấy xẻng cắm xuống thử xem.”

Chúng tôi lấy ống thép có rãnh xoáy ra lắp lưỡi xẻng vào, chú Ba lấy chân vạch mấy vệt trên mặt đất đánh dấu vị trí cần đào. Đại Khuê đầu tiên cố định đầu xẻng, sau đó lấy búa cán ngắn gõ lên, xẻng bắt đầu lún sâu xuống đất. Chú Ba đặt một bàn tay lên cán xẻng để cảm nhận tình hình bên dưới. Khi gõ đến ống thứ mười ba, chú đột nhiên nói: “Đủ rồi!”

Chúng tôi rút dần từng khúc từng khúc cán xẻng, cuối cùng cũng lấy được một ít đất. Đại Khuê tháo lưỡi xẻng ra mang đến gần đống lửa cho chúng tôi nhìn rõ. Tôi và chú Ba vừa thấy, tức thì mặt mũi đều tái đi, ngay cả Muộn Du Bình cũng “a” lên một tiếng. Hóa ra thứ đất kia giống như thấm đẫm máu, giờ đang tí tách rỉ ra thứ chất lỏng y hệt máu tươi.

Chú Ba ngửi(*) thử rồi nhíu mày. Tôi và chú Ba đã từng xem qua ghi chép về huyết thi, nhưng tình hình cụ thể thế nào, chỉ dựa vào bút ký của ông nội tôi thì không thể suy đoán được một cách chuẩn xác. Nhưng có một điều chắc chắn, nếu bùn đất ngấm máu thế kia thì dưới mộ chắc chắn đầy những bất trắc.

(*) Người ta dùng xẻng sắt xiên xuống đất rồi ngửi các thứ mùi để xác định thành phần đất, còn xẻng Lạc Dương khi xiên xuống mang đất lên chỉ cần dùng mắt cũng đủ quan sát được các thành phần thổ nhưỡng. Do chất đất ở đây quá bất thường nên mới phải ngửi, còn cơ bản, ở đây vẫn dùng xẻng Lạc Dương.

Tôi nhìn chú Ba chờ xem chú quyết định thế nào. Chú ngẫm nghĩ một hồi, châm một điếu thuốc rồi nói: “Mặc kệ đi, cứ đào ra rồi tính.”

Bên kia, Phan Tử và Đại Khuê cũng không ngừng tay, Đại Khuê sục xẻng xuống mấy lần đều đưa lưỡi xẻng cho chú Ba. Chú Ba ngửi thử từng lưỡi một, sau đó dùng bay nối liền những điểm cắm xẻng vào nhau. Tôi đứng nhìn họ bận rộn định vị, cuối cùng trên mặt đất dần hiện ra hình dạng sơ lược của cổ mộ.

Dò tìm vị trí mộ huyệt là kiến thức cơ bản của dân trộm mộ, có thể nói, đồ hình trên mặt đất thế nào, mộ bên dưới chắc chắn giống y như vậy, rất ít người tính toán sai, nhưng tôi xem qua cấu trúc này âm thầm cảm thấy có điều không ổn. Hầu như toàn bộ cổ mộ thời Chiến quốc không có địa cung, nhưng lăng mộ bên dưới này rõ ràng là có, hơn nữa nóc mộ còn xây bằng gạch, không bình thường chút nào.

Chú Ba đưa mấy ngón tay tỉ mỉ đo đạc, cuối cùng chỉ vào vị trí hạ quan tài vừa xác định được, nói: “Bên dưới đã là đỉnh mộ, không thể đâm xẻng xuống được nữa, thôi thì chỉ xác định được vị trí đại khái. Cái địa cung này rất quái, ta chẳng có tí kiến thức nào cả, đành dựa theo cổ mộ thời Tống, đào vào từ tường hậu. Nếu không được còn tìm cách khác, nhanh tay nhanh chân lên một chút!”

Mấy người chú Ba đã đi đào hầm trộm mộ dễ đến mười mấy năm, tốc độ như điện, mấy lưỡi xẻng nhấc lên hạ xuống như gió cuốn, trong chốc lát đã đào được cái động sâu tầm bảy tám mét. Đây vốn là vùng hoang dã, đất đai chẳng phải của ai, chúng tôi cứ thế xúc bùn ra. Lát sau đã nghe Đại Khuê gào lên phía bên dưới: “Quá chuẩn!”

Hang Đại Khuê đào rất lớn, gần như thủng hẳn một mảng tường mộ. Chúng tôi bật đèn mỏ soi vào bên trong, Muộn Du Bình thấy Đại Khuê tay chân khua loạn vào vách tường vội vã ngăn lại: “Đừng có chạm vào cái gì hết!”. Ánh mắt Muộn Du Bình sắc như dao tức khắc khiến Đại Khuê sợ đến nhảy dựng lên.

Hắn vươn hai ngón tay đặt lên mặt tường, chậm rãi lần theo từng kẽ gạch, một lúc lâu sau mới dừng lại mà nói: “Nơi này có tường kép chống trộm. Muốn trộm, phải lôi từng viên gạch ra. Không thể đẩy vào, phá lại càng không được.”

Phan Tử sờ sờ tường, thốt lên: “Sao có thể như thế được, ngay cả kẽ hở cũng không có? Thế này thì lôi gạch ra kiểu gì?”

Muộn Du Bình cẩn thận quan sát một lúc, hắn chạm vào một viên gạch, đột ngột tăng lực trên tay rút viên gạch đó ra khỏi vách tường. Gạch xây chắc chắn như vậy, chỉ dùng tay không mà rút cả viên gạch, chẳng hiểu hắn phải dùng đến bao nhiêu sức lực nữa. Hai ngón tay của hắn quả nhiên không tầm thường chút nào.

Hắn cẩn thận đặt viên gạch xuống đất, chỉ vào mặt sau. Chúng tôi chụm đầu vào nhìn, trông thấy rõ ràng một lớp sáp đỏ sậm.

“Những lớp tường này khi xây đều sử dụng a-xít, khi phá tường, chỉ cần chúng ta mạnh tay một chút, thứ a-xít này sẽ bắn vào người đến cháy thịt cháy da.”

Tôi nuốt nước bọt, đột nhiên nghĩ tới con quái vật tượt da mà ông nội đã nhìn thấy. Không lẽ đó không phải huyết thi, mà chính là ông cố bị đổ a-xít lên người? Không lẽ những phát súng mà ông nội bắn, chính là bắn vào ông cố?

Muộn Du Bình bảo Bàn Khuê đào một cái hố nhỏ sâu chừng năm thước rồi lấy trong túi ra một đầu kim tiêm cùng ống nhựa dẻo, cắm kim vào ống sau đó đem thả đầu kia vào hố. Phan Tử thổi ống giữ lửa (1) đốt đỏ đầu kim lên, Muộn Du Bình cẩn thận cắm ngập đầu kim vào lớp sáp trên tường. Ngay lập tức, a-xít đỏ rực theo đường ống chảy xuống hố đã được đào sẵn.

Không bao lâu, lớp sáp đỏ đã chuyển sang màu trắng toát, hình như còn có thứ gì đó lấp lánh. Muộn Du Bình gật gật đầu: “Được rồi.” Chúng tôi tức thì bắt tay vào đào. Chẳng mấy chốc, một hang động đủ cho một người chui qua đã hiện ra trên vách tường. Chú Ba thổi lửa soi vào động, theo ánh lửa mà quan sát bên trong.

Chúng tôi tiến vào từ hướng Bắc, vừa đi vừa nhìn ngó xung quanh. Trên mặt đất lát bằng toàn những phiến đá tảng, bên trên khắc chi chít văn tự cổ đại. Những phiến đá này đều được sắp xếp theo phương vị bát quái, bên ngoài là tảng to, càng vào bên trong càng nhỏ. Bốn phía huyệt mộ là tám ngọn Trường minh đăng(2), tất nhiên đều đã tắt ngóm từ lâu. Giữa huyệt bày một chiếc đỉnh vuông bốn chân, trên có biểu tượng mặt trăng, mặt trời và các vì sao. Phía Nam mộ thất, ngay hướng đối diện chúng tôi đặt một quan tài đá. Phía sau quan tài là một lối đi, hình như là hướng xuống dưới, không rõ nó dẫn đến nơi quái quỷ nào nữa.

Chú Ba bước tới nghe ngóng thăm dò, sau đó vẫy vẫy tay, chúng tôi lần lượt từng người chui vào.

Chú nhìn những văn tự chằng chịt trên mặt đất, quay sang hỏi Muộn Du Bình: “Tiểu Ca, cậu xem những chữ này, liệu có luận ra được nơi đây mai táng người nào không?”

Muộn Du Bình lắc đầu không nói gì.

Chúng tôi châm lửa thắp vào Trường minh đăng, cả mộ thất tức khắc sáng bừng lên. Tôi lại liên tưởng đến con quái vật trong bút ký của ông nội, hình như…ông còn nhiều lần nhắc đến việc nghe thấy tiếng cười kèng kẹc, nghĩ đến đây tôi bất giác sợ run lên. Phan Tử bước đến gần cái đỉnh, nghiêng đầu ngó vào xem có gì bên trong. Đột nhiên, hắn hô lên một tiếng: “Lão Ba, ở đây có báu vật!”

Chúng tôi đều tiến lên xem, thấy ngay một cái xác không đầu khô quắt, quần áo đã rữa nát hết, trên người nó có vài món trang sức bằng ngọc. Gã Phan Tử làm ẩu không thèm nể mặt người chết, thẳng tay giật khối ngọc xuống.

“Chắc đây là thân thể của người theo bồi táng ở thế giới bên kia. Họ chặt đầu tế trời, sau đó mang xác đến đây tế người. Kẻ này có lẽ là tù binh, thân phận nô lệ làm sao có được thứ trang sức kia.”

Phan Tử đột ngột co chân nhảy vào trong đỉnh để mò mẫm thêm bảo vật, Muộn Du Bình muốn ngăn cũng không kịp, chỉ còn biết quay đầu lại cảnh giác nhìn chiếc quan tài đá, cũng may nó vẫn im lìm không có động tĩnh gì. Chú Ba quát loạn: “Thằng kia, đỉnh này là đồ đựng tế phẩm người ta dùng để cúng bái cho tổ tiên, cái thằng oắt nhà mày muốn thành tế phẩm hay sao?!”

Phan Tử cười ha hả: “Lão Ba, tôi đây đâu phải Đại Khuê, đừng có dọa tôi.” Hắn lấy thêm một cái bình ngọc lớn: “Ông nhìn đi, toàn những thứ thượng hạng, theo tôi chúng ta đổ quách cái đỉnh này ra xem bên trong còn có những gì…”

“Đừng có làm bậy, mày vác xác ra ngay đi!” Chú Ba nói, lo lắng nhìn sắc mặt Muộn Du Bình lúc này đã tái đi, ánh mắt gắt gao dán chặt vào quan tài đá như thể biết chắc sẽ có chuyện chẳng lành.

Đúng lúc đó, tôi chợt nghe một tiếng cười khành khạch. Tôi quay đầu, xương sống một đợt gai lạnh. Tiếng cười kia không phát ra từ quan tài, mà chính là từ Muộn Du Bình vọng lại.

—————————————-

Chú thích

(1) Nguyên văn: Hỏa chiết tử. Bộ dụng cụ lấy lửa thời xưa gồm que đánh lửa, đá lửa và ống giữ lửa. Trong đó ống giữ lửa rất tiện dụng, là một ống đựng mồi lửa có thể đem theo bên mình, khi cần có thể rút ra châm lửa hoặc dùng thay cho đuốc thắp sáng. Phương pháp làm ống giữ lửa là lấy dây khoai trắng hoặc tím ngâm trong nước cho nở, vớt ra đập dập, lại ngâm chung thêm với bông vải, bông lau vớt ra đập dập, phơi khô, trộn thêm các loại vật liệu dễ cháy như kali, lưu huỳnh, nhựa thông, long não chế thành. Xong xuôi bện lại thành dây thừng hoặc buộc thành hình ống dài nén vào ống trúc, châm lửa cho cháy ngún rồi đậy kín lại, lúc cần dùng rút nắp ra là cháy, rất dễ cháy, là loại vua chúa hoặc nhà có tiền sử dụng. Nhà bình thường có thể dùng các loại giấy cắt thành dạng dài hơn ống trúc, cuộn đều tay, nhét vào trong ống. Sau đó châm lửa, rồi đậy nắp thông gió lại, tàn lửa sẽ được giữ trong ống. Lúc cần dùng bật nắp, thổi nhè nhẹ để lửa cháy lên, khi thổi cần phải có kỹ thuật thì lửa mới cháy lên được.

Đây là mô tả trên baidu, tả ống giữ lửa thời phong kiến, mình nghĩ loại dùng trong truyện là loại có tẩm vật liệu dễ cháy, chỉ cần rút nắp ra để tàn lửa âm ỉ trong ống tiếp xúc với oxy là lửa sẽ lập tức bùng lên.

Hình:

(1) Trường minh đăng:

长明灯

Đèn thắp để thờ cúng, là loại đèn không thể thổi tắt mà qua một thời gian sẽ tự tắt, còn có tên khác là Minh đăng, hoặc Vô tận đăng. Lăng mộ vua chúa Trung Hoa cũng đặt Trường minh đăng với hi vọng lăng mộ sáng tỏ huy hoàng như cung điện lúc sinh thời
Chiếc di động kia hẳn là mới bỏ lại chưa lâu, tôi vừa nhặt lên liền thấy ngay vệt máu loãng dính trên đó, tức thì có linh cảm không lành: “Xem ra nơi này còn một nhóm khác, hơn nữa hình như có người bị thương. Điện thoại làm sao từ trên trời rơi xuống được?”

Tôi mở nắp máy, trên màn hình có mấy dãy số liền nhau đều là số điện thoại ngoại quốc, ngoài ra cũng không thu được thêm thông tin gì. Chú Ba nói: “Dù thế nào chúng ta cũng không thể đi tìm họ, trước mắt cứ lên đường đã.” Tôi xem xét bốn phía chẳng có chút manh mối, đành phải mở đường tiếp tục đi. Tuy vậy, giữa vùng hoang sơn dã lĩnh lại bắt gặp một thứ đồ từ thế giới văn minh vẫn cảm thấy thật khó tưởng tượng. Tôi lên tiếng hỏi lão già kia, ngoài chúng tôi ra có ai khác tiến vào khu rừng này hay không.

Lão cười hề hề đáp: “Cách đây hai tuần có một toán khoảng trên mười người, đến nay vẫn chưa thấy trở ra. Nơi đây rất nguy hiểm, các vị, giờ quay lại vẫn còn kịp đó.”

“Cứ cho là có yêu ma quỷ quái thì đã sao?” Đại Khuê nói “Nói cho ông biết, cương thi ngàn năm gặp anh chàng này của chúng tôi còn phải phục xuống dập đầu, có hắn ở đây thì yêu quái nhằm nhò gì, đúng không?” Hắn hỏi Muộn Du Bình, Muộn Du Bình không có chút phản ứng, như thể xem lời hắn nói là không khí vậy. Đại Khuê như đụng phải gai, bực tức cũng chẳng làm gì được.

Chúng tôi lặng lẽ đi tiếp. Chưa đến bốn giờ chiều mà đất trời đã tối tăm mù mịt, rốt cuộc cũng đến nơi cần đến.

Thứ đầu tiên đập vào mắt là mười mấy chiếc lều trại quân dụng hầu như còn nguyên vẹn. Đây là loại lều chất lượng cực kỳ tốt, tuy trên nóc phủ đầy lá rụng đang mục nát nhưng bên trong khô ráo sạch sẽ, ngoài ra còn có không ít vật dụng thông thường. Chúng tôi cứ tùy tiện xem xét, xung quanh rải rác vô số vũ khí quân trang nhưng hoàn toàn không có thi thể, ông già kia chưa hẳn đã nói dối.

Thậm chí chúng tôi còn tìm được cả một chiếc máy phát điện cùng mấy ống đựng xăng, tuy động cơ đã được tra dầu nhưng phần lớn linh kiện đều rơi vào tình trạng rỉ sét. Bàn Khuê thử khởi động thì không có chút động tĩnh gì, chỉ có xăng vẫn ok. Tôi thử lật đi lật lại, phát hiện ra tất cả đồ đạc đều bị xé nhãn, ngay cả nhãn hiệu lều trại và ba lô của bọn họ cũng trống trơn, thật là kỳ quái. Có vẻ như, những người này một mực không muốn kẻ khác lần ra lai lịch của họ.

Chúng tôi ở lại doanh địa đó nhóm lửa rồi ăn qua quýt một bữa cơm chiều. Lão già vừa ăn vừa mắt la mày lét cảnh giác nhìn bốn phía như thể sợ yêu quái sẽ đột nhiên xông vào mà treo cổ lão lên vậy. Mấy thứ đồ ăn đóng hộp, thực lòng mà nói vô cùng khó nuốt, tôi hầu như chỉ uống vài ngụm nước cho qua bữa.

Muộn Du Bình vừa ăn vừa xem bản đồ, hắn chỉ vào một địa điểm có vẽ hình mặt hồ ly quái dị trên đó: “Hiện giờ chắc chắn chúng ta đang ở đây.”

Sau khi chúng tôi đã nhìn rõ, hắn nói tiếp: “Chỗ này là nơi cúng tế, phía dưới hẳn là đài cúng tế. Những đồ bồi táng có lẽ ở ngay đây thôi.”

Chú Ba ngồi xổm trên mặt đất vốc một nắm đất đưa lên mũi ngửi qua, lắc đầu rồi tiến vài bước, lại xem xét rồi nói: “Chôn sâu quá, lấy xẻng cắm xuống thử xem.”

Chúng tôi lấy ống thép có rãnh xoáy ra lắp lưỡi xẻng vào, chú Ba lấy chân vạch mấy vệt trên mặt đất đánh dấu vị trí cần đào. Đại Khuê đầu tiên cố định đầu xẻng, sau đó lấy búa cán ngắn gõ lên, xẻng bắt đầu lún sâu xuống đất. Chú Ba đặt một bàn tay lên cán xẻng để cảm nhận tình hình bên dưới. Khi gõ đến ống thứ mười ba, chú đột nhiên nói: “Đủ rồi!”

Chúng tôi rút dần từng khúc từng khúc cán xẻng, cuối cùng cũng lấy được một ít đất. Đại Khuê tháo lưỡi xẻng ra mang đến gần đống lửa cho chúng tôi nhìn rõ. Tôi và chú Ba vừa thấy, tức thì mặt mũi đều tái đi, ngay cả Muộn Du Bình cũng “a” lên một tiếng. Hóa ra thứ đất kia giống như thấm đẫm máu, giờ đang tí tách rỉ ra thứ chất lỏng y hệt máu tươi.

Chú Ba ngửi(*) thử rồi nhíu mày. Tôi và chú Ba đã từng xem qua ghi chép về huyết thi, nhưng tình hình cụ thể thế nào, chỉ dựa vào bút ký của ông nội tôi thì không thể suy đoán được một cách chuẩn xác. Nhưng có một điều chắc chắn, nếu bùn đất ngấm máu thế kia thì dưới mộ chắc chắn đầy những bất trắc.

(*) Người ta dùng xẻng sắt xiên xuống đất rồi ngửi các thứ mùi để xác định thành phần đất, còn xẻng Lạc Dương khi xiên xuống mang đất lên chỉ cần dùng mắt cũng đủ quan sát được các thành phần thổ nhưỡng. Do chất đất ở đây quá bất thường nên mới phải ngửi, còn cơ bản, ở đây vẫn dùng xẻng Lạc Dương.

Tôi nhìn chú Ba chờ xem chú quyết định thế nào. Chú ngẫm nghĩ một hồi, châm một điếu thuốc rồi nói: “Mặc kệ đi, cứ đào ra rồi tính.”

Bên kia, Phan Tử và Đại Khuê cũng không ngừng tay, Đại Khuê sục xẻng xuống mấy lần đều đưa lưỡi xẻng cho chú Ba. Chú Ba ngửi thử từng lưỡi một, sau đó dùng bay nối liền những điểm cắm xẻng vào nhau. Tôi đứng nhìn họ bận rộn định vị, cuối cùng trên mặt đất dần hiện ra hình dạng sơ lược của cổ mộ.

Dò tìm vị trí mộ huyệt là kiến thức cơ bản của dân trộm mộ, có thể nói, đồ hình trên mặt đất thế nào, mộ bên dưới chắc chắn giống y như vậy, rất ít người tính toán sai, nhưng tôi xem qua cấu trúc này âm thầm cảm thấy có điều không ổn. Hầu như toàn bộ cổ mộ thời Chiến quốc không có địa cung, nhưng lăng mộ bên dưới này rõ ràng là có, hơn nữa nóc mộ còn xây bằng gạch, không bình thường chút nào.

Chú Ba đưa mấy ngón tay tỉ mỉ đo đạc, cuối cùng chỉ vào vị trí hạ quan tài vừa xác định được, nói: “Bên dưới đã là đỉnh mộ, không thể đâm xẻng xuống được nữa, thôi thì chỉ xác định được vị trí đại khái. Cái địa cung này rất quái, ta chẳng có tí kiến thức nào cả, đành dựa theo cổ mộ thời Tống, đào vào từ tường hậu. Nếu không được còn tìm cách khác, nhanh tay nhanh chân lên một chút!”

Mấy người chú Ba đã đi đào hầm trộm mộ dễ đến mười mấy năm, tốc độ như điện, mấy lưỡi xẻng nhấc lên hạ xuống như gió cuốn, trong chốc lát đã đào được cái động sâu tầm bảy tám mét. Đây vốn là vùng hoang dã, đất đai chẳng phải của ai, chúng tôi cứ thế xúc bùn ra. Lát sau đã nghe Đại Khuê gào lên phía bên dưới: “Quá chuẩn!”

Hang Đại Khuê đào rất lớn, gần như thủng hẳn một mảng tường mộ. Chúng tôi bật đèn mỏ soi vào bên trong, Muộn Du Bình thấy Đại Khuê tay chân khua loạn vào vách tường vội vã ngăn lại: “Đừng có chạm vào cái gì hết!”. Ánh mắt Muộn Du Bình sắc như dao tức khắc khiến Đại Khuê sợ đến nhảy dựng lên.

Hắn vươn hai ngón tay đặt lên mặt tường, chậm rãi lần theo từng kẽ gạch, một lúc lâu sau mới dừng lại mà nói: “Nơi này có tường kép chống trộm. Muốn trộm, phải lôi từng viên gạch ra. Không thể đẩy vào, phá lại càng không được.”

Phan Tử sờ sờ tường, thốt lên: “Sao có thể như thế được, ngay cả kẽ hở cũng không có? Thế này thì lôi gạch ra kiểu gì?”

Muộn Du Bình cẩn thận quan sát một lúc, hắn chạm vào một viên gạch, đột ngột tăng lực trên tay rút viên gạch đó ra khỏi vách tường. Gạch xây chắc chắn như vậy, chỉ dùng tay không mà rút cả viên gạch, chẳng hiểu hắn phải dùng đến bao nhiêu sức lực nữa. Hai ngón tay của hắn quả nhiên không tầm thường chút nào.

Hắn cẩn thận đặt viên gạch xuống đất, chỉ vào mặt sau. Chúng tôi chụm đầu vào nhìn, trông thấy rõ ràng một lớp sáp đỏ sậm.

“Những lớp tường này khi xây đều sử dụng a-xít, khi phá tường, chỉ cần chúng ta mạnh tay một chút, thứ a-xít này sẽ bắn vào người đến cháy thịt cháy da.”

Tôi nuốt nước bọt, đột nhiên nghĩ tới con quái vật tượt da mà ông nội đã nhìn thấy. Không lẽ đó không phải huyết thi, mà chính là ông cố bị đổ a-xít lên người? Không lẽ những phát súng mà ông nội bắn, chính là bắn vào ông cố?

Muộn Du Bình bảo Bàn Khuê đào một cái hố nhỏ sâu chừng năm thước rồi lấy trong túi ra một đầu kim tiêm cùng ống nhựa dẻo, cắm kim vào ống sau đó đem thả đầu kia vào hố. Phan Tử thổi ống giữ lửa (1) đốt đỏ đầu kim lên, Muộn Du Bình cẩn thận cắm ngập đầu kim vào lớp sáp trên tường. Ngay lập tức, a-xít đỏ rực theo đường ống chảy xuống hố đã được đào sẵn.

Không bao lâu, lớp sáp đỏ đã chuyển sang màu trắng toát, hình như còn có thứ gì đó lấp lánh. Muộn Du Bình gật gật đầu: “Được rồi.” Chúng tôi tức thì bắt tay vào đào. Chẳng mấy chốc, một hang động đủ cho một người chui qua đã hiện ra trên vách tường. Chú Ba thổi lửa soi vào động, theo ánh lửa mà quan sát bên trong.

Chúng tôi tiến vào từ hướng Bắc, vừa đi vừa nhìn ngó xung quanh. Trên mặt đất lát bằng toàn những phiến đá tảng, bên trên khắc chi chít văn tự cổ đại. Những phiến đá này đều được sắp xếp theo phương vị bát quái, bên ngoài là tảng to, càng vào bên trong càng nhỏ. Bốn phía huyệt mộ là tám ngọn Trường minh đăng(2), tất nhiên đều đã tắt ngóm từ lâu. Giữa huyệt bày một chiếc đỉnh vuông bốn chân, trên có biểu tượng mặt trăng, mặt trời và các vì sao. Phía Nam mộ thất, ngay hướng đối diện chúng tôi đặt một quan tài đá. Phía sau quan tài là một lối đi, hình như là hướng xuống dưới, không rõ nó dẫn đến nơi quái quỷ nào nữa.

Chú Ba bước tới nghe ngóng thăm dò, sau đó vẫy vẫy tay, chúng tôi lần lượt từng người chui vào.

Chú nhìn những văn tự chằng chịt trên mặt đất, quay sang hỏi Muộn Du Bình: “Tiểu Ca, cậu xem những chữ này, liệu có luận ra được nơi đây mai táng người nào không?”

Muộn Du Bình lắc đầu không nói gì.

Chúng tôi châm lửa thắp vào Trường minh đăng, cả mộ thất tức khắc sáng bừng lên. Tôi lại liên tưởng đến con quái vật trong bút ký của ông nội, hình như…ông còn nhiều lần nhắc đến việc nghe thấy tiếng cười kèng kẹc, nghĩ đến đây tôi bất giác sợ run lên. Phan Tử bước đến gần cái đỉnh, nghiêng đầu ngó vào xem có gì bên trong. Đột nhiên, hắn hô lên một tiếng: “Lão Ba, ở đây có báu vật!”

Chúng tôi đều tiến lên xem, thấy ngay một cái xác không đầu khô quắt, quần áo đã rữa nát hết, trên người nó có vài món trang sức bằng ngọc. Gã Phan Tử làm ẩu không thèm nể mặt người chết, thẳng tay giật khối ngọc xuống.

“Chắc đây là thân thể của người theo bồi táng ở thế giới bên kia. Họ chặt đầu tế trời, sau đó mang xác đến đây tế người. Kẻ này có lẽ là tù binh, thân phận nô lệ làm sao có được thứ trang sức kia.”

Phan Tử đột ngột co chân nhảy vào trong đỉnh để mò mẫm thêm bảo vật, Muộn Du Bình muốn ngăn cũng không kịp, chỉ còn biết quay đầu lại cảnh giác nhìn chiếc quan tài đá, cũng may nó vẫn im lìm không có động tĩnh gì. Chú Ba quát loạn: “Thằng kia, đỉnh này là đồ đựng tế phẩm người ta dùng để cúng bái cho tổ tiên, cái thằng oắt nhà mày muốn thành tế phẩm hay sao?!”

Phan Tử cười ha hả: “Lão Ba, tôi đây đâu phải Đại Khuê, đừng có dọa tôi.” Hắn lấy thêm một cái bình ngọc lớn: “Ông nhìn đi, toàn những thứ thượng hạng, theo tôi chúng ta đổ quách cái đỉnh này ra xem bên trong còn có những gì…”

“Đừng có làm bậy, mày vác xác ra ngay đi!” Chú Ba nói, lo lắng nhìn sắc mặt Muộn Du Bình lúc này đã tái đi, ánh mắt gắt gao dán chặt vào quan tài đá như thể biết chắc sẽ có chuyện chẳng lành.

Đúng lúc đó, tôi chợt nghe một tiếng cười khành khạch. Tôi quay đầu, xương sống một đợt gai lạnh. Tiếng cười kia không phát ra từ quan tài, mà chính là từ Muộn Du Bình vọng lại.

—————————————-

Chú thích

(1) Nguyên văn: Hỏa chiết tử. Bộ dụng cụ lấy lửa thời xưa gồm que đánh lửa, đá lửa và ống giữ lửa. Trong đó ống giữ lửa rất tiện dụng, là một ống đựng mồi lửa có thể đem theo bên mình, khi cần có thể rút ra châm lửa hoặc dùng thay cho đuốc thắp sáng. Phương pháp làm ống giữ lửa là lấy dây khoai trắng hoặc tím ngâm trong nước cho nở, vớt ra đập dập, lại ngâm chung thêm với bông vải, bông lau vớt ra đập dập, phơi khô, trộn thêm các loại vật liệu dễ cháy như kali, lưu huỳnh, nhựa thông, long não chế thành. Xong xuôi bện lại thành dây thừng hoặc buộc thành hình ống dài nén vào ống trúc, châm lửa cho cháy ngún rồi đậy kín lại, lúc cần dùng rút nắp ra là cháy, rất dễ cháy, là loại vua chúa hoặc nhà có tiền sử dụng. Nhà bình thường có thể dùng các loại giấy cắt thành dạng dài hơn ống trúc, cuộn đều tay, nhét vào trong ống. Sau đó châm lửa, rồi đậy nắp thông gió lại, tàn lửa sẽ được giữ trong ống. Lúc cần dùng bật nắp, thổi nhè nhẹ để lửa cháy lên, khi thổi cần phải có kỹ thuật thì lửa mới cháy lên được.

Đây là mô tả trên baidu, tả ống giữ lửa thời phong kiến, mình nghĩ loại dùng trong truyện là loại có tẩm vật liệu dễ cháy, chỉ cần rút nắp ra để tàn lửa âm ỉ trong ống tiếp xúc với oxy là lửa sẽ lập tức bùng lên.

Hình:

(1) Trường minh đăng:

长明灯

Đèn thắp để thờ cúng, là loại đèn không thể thổi tắt mà qua một thời gian sẽ tự tắt, còn có tên khác là Minh đăng, hoặc Vô tận đăng. Lăng mộ vua chúa Trung Hoa cũng đặt Trường minh đăng với hi vọng

Chiếc di động kia hẳn là mới bỏ lại chưa lâu, tôi vừa nhặt lên liền thấy ngay vệt máu loãng dính trên đó, tức thì có linh cảm không lành: “Xem ra nơi này còn một nhóm khác, hơn nữa hình như có người bị thương. Điện thoại làm sao từ trên trời rơi xuống được?”

Tôi mở nắp máy, trên màn hình có mấy dãy số liền nhau đều là số điện thoại ngoại quốc, ngoài ra cũng không thu được thêm thông tin gì. Chú Ba nói: “Dù thế nào chúng ta cũng không thể đi tìm họ, trước mắt cứ lên đường đã.” Tôi xem xét bốn phía chẳng có chút manh mối, đành phải mở đường tiếp tục đi. Tuy vậy, giữa vùng hoang sơn dã lĩnh lại bắt gặp một thứ đồ từ thế giới văn minh vẫn cảm thấy thật khó tưởng tượng. Tôi lên tiếng hỏi lão già kia, ngoài chúng tôi ra có ai khác tiến vào khu rừng này hay không.

Lão cười hề hề đáp: “Cách đây hai tuần có một toán khoảng trên mười người, đến nay vẫn chưa thấy trở ra. Nơi đây rất nguy hiểm, các vị, giờ quay lại vẫn còn kịp đó.”

“Cứ cho là có yêu ma quỷ quái thì đã sao?” Đại Khuê nói “Nói cho ông biết, cương thi ngàn năm gặp anh chàng này của chúng tôi còn phải phục xuống dập đầu, có hắn ở đây thì yêu quái nhằm nhò gì, đúng không?” Hắn hỏi Muộn Du Bình, Muộn Du Bình không có chút phản ứng, như thể xem lời hắn nói là không khí vậy. Đại Khuê như đụng phải gai, bực tức cũng chẳng làm gì được.

Chúng tôi lặng lẽ đi tiếp. Chưa đến bốn giờ chiều mà đất trời đã tối tăm mù mịt, rốt cuộc cũng đến nơi cần đến.

Thứ đầu tiên đập vào mắt là mười mấy chiếc lều trại quân dụng hầu như còn nguyên vẹn. Đây là loại lều chất lượng cực kỳ tốt, tuy trên nóc phủ đầy lá rụng đang mục nát nhưng bên trong khô ráo sạch sẽ, ngoài ra còn có không ít vật dụng thông thường. Chúng tôi cứ tùy tiện xem xét, xung quanh rải rác vô số vũ khí quân trang nhưng hoàn toàn không có thi thể, ông già kia chưa hẳn đã nói dối.

Thậm chí chúng tôi còn tìm được cả một chiếc máy phát điện cùng mấy ống đựng xăng, tuy động cơ đã được tra dầu nhưng phần lớn linh kiện đều rơi vào tình trạng rỉ sét. Bàn Khuê thử khởi động thì không có chút động tĩnh gì, chỉ có xăng vẫn ok. Tôi thử lật đi lật lại, phát hiện ra tất cả đồ đạc đều bị xé nhãn, ngay cả nhãn hiệu lều trại và ba lô của bọn họ cũng trống trơn, thật là kỳ quái. Có vẻ như, những người này một mực không muốn kẻ khác lần ra lai lịch của họ.

Chúng tôi ở lại doanh địa đó nhóm lửa rồi ăn qua quýt một bữa cơm chiều. Lão già vừa ăn vừa mắt la mày lét cảnh giác nhìn bốn phía như thể sợ yêu quái sẽ đột nhiên xông vào mà treo cổ lão lên vậy. Mấy thứ đồ ăn đóng hộp, thực lòng mà nói vô cùng khó nuốt, tôi hầu như chỉ uống vài ngụm nước cho qua bữa.

Muộn Du Bình vừa ăn vừa xem bản đồ, hắn chỉ vào một địa điểm có vẽ hình mặt hồ ly quái dị trên đó: “Hiện giờ chắc chắn chúng ta đang ở đây.”

Sau khi chúng tôi đã nhìn rõ, hắn nói tiếp: “Chỗ này là nơi cúng tế, phía dưới hẳn là đài cúng tế. Những đồ bồi táng có lẽ ở ngay đây thôi.”

Chú Ba ngồi xổm trên mặt đất vốc một nắm đất đưa lên mũi ngửi qua, lắc đầu rồi tiến vài bước, lại xem xét rồi nói: “Chôn sâu quá, lấy xẻng cắm xuống thử xem.”

Chúng tôi lấy ống thép có rãnh xoáy ra lắp lưỡi xẻng vào, chú Ba lấy chân vạch mấy vệt trên mặt đất đánh dấu vị trí cần đào. Đại Khuê đầu tiên cố định đầu xẻng, sau đó lấy búa cán ngắn gõ lên, xẻng bắt đầu lún sâu xuống đất. Chú Ba đặt một bàn tay lên cán xẻng để cảm nhận tình hình bên dưới. Khi gõ đến ống thứ mười ba, chú đột nhiên nói: “Đủ rồi!”

Chúng tôi rút dần từng khúc từng khúc cán xẻng, cuối cùng cũng lấy được một ít đất. Đại Khuê tháo lưỡi xẻng ra mang đến gần đống lửa cho chúng tôi nhìn rõ. Tôi và chú Ba vừa thấy, tức thì mặt mũi đều tái đi, ngay cả Muộn Du Bình cũng “a” lên một tiếng. Hóa ra thứ đất kia giống như thấm đẫm máu, giờ đang tí tách rỉ ra thứ chất lỏng y hệt máu tươi.

Chú Ba ngửi(*) thử rồi nhíu mày. Tôi và chú Ba đã từng xem qua ghi chép về huyết thi, nhưng tình hình cụ thể thế nào, chỉ dựa vào bút ký của ông nội tôi thì không thể suy đoán được một cách chuẩn xác. Nhưng có một điều chắc chắn, nếu bùn đất ngấm máu thế kia thì dưới mộ chắc chắn đầy những bất trắc.

(*) Người ta dùng xẻng sắt xiên xuống đất rồi ngửi các thứ mùi để xác định thành phần đất, còn xẻng Lạc Dương khi xiên xuống mang đất lên chỉ cần dùng mắt cũng đủ quan sát được các thành phần thổ nhưỡng. Do chất đất ở đây quá bất thường nên mới phải ngửi, còn cơ bản, ở đây vẫn dùng xẻng Lạc Dương.

Tôi nhìn chú Ba chờ xem chú quyết định thế nào. Chú ngẫm nghĩ một hồi, châm một điếu thuốc rồi nói: “Mặc kệ đi, cứ đào ra rồi tính.”

Bên kia, Phan Tử và Đại Khuê cũng không ngừng tay, Đại Khuê sục xẻng xuống mấy lần đều đưa lưỡi xẻng cho chú Ba. Chú Ba ngửi thử từng lưỡi một, sau đó dùng bay nối liền những điểm cắm xẻng vào nhau. Tôi đứng nhìn họ bận rộn định vị, cuối cùng trên mặt đất dần hiện ra hình dạng sơ lược của cổ mộ.

Dò tìm vị trí mộ huyệt là kiến thức cơ bản của dân trộm mộ, có thể nói, đồ hình trên mặt đất thế nào, mộ bên dưới chắc chắn giống y như vậy, rất ít người tính toán sai, nhưng tôi xem qua cấu trúc này âm thầm cảm thấy có điều không ổn. Hầu như toàn bộ cổ mộ thời Chiến quốc không có địa cung, nhưng lăng mộ bên dưới này rõ ràng là có, hơn nữa nóc mộ còn xây bằng gạch, không bình thường chút nào.

Chú Ba đưa mấy ngón tay tỉ mỉ đo đạc, cuối cùng chỉ vào vị trí hạ quan tài vừa xác định được, nói: “Bên dưới đã là đỉnh mộ, không thể đâm xẻng xuống được nữa, thôi thì chỉ xác định được vị trí đại khái. Cái địa cung này rất quái, ta chẳng có tí kiến thức nào cả, đành dựa theo cổ mộ thời Tống, đào vào từ tường hậu. Nếu không được còn tìm cách khác, nhanh tay nhanh chân lên một chút!”

Mấy người chú Ba đã đi đào hầm trộm mộ dễ đến mười mấy năm, tốc độ như điện, mấy lưỡi xẻng nhấc lên hạ xuống như gió cuốn, trong chốc lát đã đào được cái động sâu tầm bảy tám mét. Đây vốn là vùng hoang dã, đất đai chẳng phải của ai, chúng tôi cứ thế xúc bùn ra. Lát sau đã nghe Đại Khuê gào lên phía bên dưới: “Quá chuẩn!”

Hang Đại Khuê đào rất lớn, gần như thủng hẳn một mảng tường mộ. Chúng tôi bật đèn mỏ soi vào bên trong, Muộn Du Bình thấy Đại Khuê tay chân khua loạn vào vách tường vội vã ngăn lại: “Đừng có chạm vào cái gì hết!”. Ánh mắt Muộn Du Bình sắc như dao tức khắc khiến Đại Khuê sợ đến nhảy dựng lên.

Hắn vươn hai ngón tay đặt lên mặt tường, chậm rãi lần theo từng kẽ gạch, một lúc lâu sau mới dừng lại mà nói: “Nơi này có tường kép chống trộm. Muốn trộm, phải lôi từng viên gạch ra. Không thể đẩy vào, phá lại càng không được.”

Phan Tử sờ sờ tường, thốt lên: “Sao có thể như thế được, ngay cả kẽ hở cũng không có? Thế này thì lôi gạch ra kiểu gì?”

Muộn Du Bình cẩn thận quan sát một lúc, hắn chạm vào một viên gạch, đột ngột tăng lực trên tay rút viên gạch đó ra khỏi vách tường. Gạch xây chắc chắn như vậy, chỉ dùng tay không mà rút cả viên gạch, chẳng hiểu hắn phải dùng đến bao nhiêu sức lực nữa. Hai ngón tay của hắn quả nhiên không tầm thường chút nào.

Hắn cẩn thận đặt viên gạch xuống đất, chỉ vào mặt sau. Chúng tôi chụm đầu vào nhìn, trông thấy rõ ràng một lớp sáp đỏ sậm.

“Những lớp tường này khi xây đều sử dụng a-xít, khi phá tường, chỉ cần chúng ta mạnh tay một chút, thứ a-xít này sẽ bắn vào người đến cháy thịt cháy da.”

Tôi nuốt nước bọt, đột nhiên nghĩ tới con quái vật tượt da mà ông nội đã nhìn thấy. Không lẽ đó không phải huyết thi, mà chính là ông cố bị đổ a-xít lên người? Không lẽ những phát súng mà ông nội bắn, chính là bắn vào ông cố?

Muộn Du Bình bảo Bàn Khuê đào một cái hố nhỏ sâu chừng năm thước rồi lấy trong túi ra một đầu kim tiêm cùng ống nhựa dẻo, cắm kim vào ống sau đó đem thả đầu kia vào hố. Phan Tử thổi ống giữ lửa (1) đốt đỏ đầu kim lên, Muộn Du Bình cẩn thận cắm ngập đầu kim vào lớp sáp trên tường. Ngay lập tức, a-xít đỏ rực theo đường ống chảy xuống hố đã được đào sẵn.

Không bao lâu, lớp sáp đỏ đã chuyển sang màu trắng toát, hình như còn có thứ gì đó lấp lánh. Muộn Du Bình gật gật đầu: “Được rồi.” Chúng tôi tức thì bắt tay vào đào. Chẳng mấy chốc, một hang động đủ cho một người chui qua đã hiện ra trên vách tường. Chú Ba thổi lửa soi vào động, theo ánh lửa mà quan sát bên trong.

Chúng tôi tiến vào từ hướng Bắc, vừa đi vừa nhìn ngó xung quanh. Trên mặt đất lát bằng toàn những phiến đá tảng, bên trên khắc chi chít văn tự cổ đại. Những phiến đá này đều được sắp xếp theo phương vị bát quái, bên ngoài là tảng to, càng vào bên trong càng nhỏ. Bốn phía huyệt mộ là tám ngọn Trường minh đăng(2), tất nhiên đều đã tắt ngóm từ lâu. Giữa huyệt bày một chiếc đỉnh vuông bốn chân, trên có biểu tượng mặt trăng, mặt trời và các vì sao. Phía Nam mộ thất, ngay hướng đối diện chúng tôi đặt một quan tài đá. Phía sau quan tài là một lối đi, hình như là hướng xuống dưới, không rõ nó dẫn đến nơi quái quỷ nào nữa.

Chú Ba bước tới nghe ngóng thăm dò, sau đó vẫy vẫy tay, chúng tôi lần lượt từng người chui vào.

Chú nhìn những văn tự chằng chịt trên mặt đất, quay sang hỏi Muộn Du Bình: “Tiểu Ca, cậu xem những chữ này, liệu có luận ra được nơi đây mai táng người nào không?”

Muộn Du Bình lắc đầu không nói gì.

Chúng tôi châm lửa thắp vào Trường minh đăng, cả mộ thất tức khắc sáng bừng lên. Tôi lại liên tưởng đến con quái vật trong bút ký của ông nội, hình như…ông còn nhiều lần nhắc đến việc nghe thấy tiếng cười kèng kẹc, nghĩ đến đây tôi bất giác sợ run lên. Phan Tử bước đến gần cái đỉnh, nghiêng đầu ngó vào xem có gì bên trong. Đột nhiên, hắn hô lên một tiếng: “Lão Ba, ở đây có báu vật!”

Chúng tôi đều tiến lên xem, thấy ngay một cái xác không đầu khô quắt, quần áo đã rữa nát hết, trên người nó có vài món trang sức bằng ngọc. Gã Phan Tử làm ẩu không thèm nể mặt người chết, thẳng tay giật khối ngọc xuống.

“Chắc đây là thân thể của người theo bồi táng ở thế giới bên kia. Họ chặt đầu tế trời, sau đó mang xác đến đây tế người. Kẻ này có lẽ là tù binh, thân phận nô lệ làm sao có được thứ trang sức kia.”

Phan Tử đột ngột co chân nhảy vào trong đỉnh để mò mẫm thêm bảo vật, Muộn Du Bình muốn ngăn cũng không kịp, chỉ còn biết quay đầu lại cảnh giác nhìn chiếc quan tài đá, cũng may nó vẫn im lìm không có động tĩnh gì. Chú Ba quát loạn: “Thằng kia, đỉnh này là đồ đựng tế phẩm người ta dùng để cúng bái cho tổ tiên, cái thằng oắt nhà mày muốn thành tế phẩm hay sao?!”

Phan Tử cười ha hả: “Lão Ba, tôi đây đâu phải Đại Khuê, đừng có dọa tôi.” Hắn lấy thêm một cái bình ngọc lớn: “Ông nhìn đi, toàn những thứ thượng hạng, theo tôi chúng ta đổ quách cái đỉnh này ra xem bên trong còn có những gì…”

“Đừng có làm bậy, mày vác xác ra ngay đi!” Chú Ba nói, lo lắng nhìn sắc mặt Muộn Du Bình lúc này đã tái đi, ánh mắt gắt gao dán chặt vào quan tài đá như thể biết chắc sẽ có chuyện chẳng lành.

Đúng lúc đó, tôi chợt nghe một tiếng cười khành khạch. Tôi quay đầu, xương sống một đợt gai lạnh. Tiếng cười kia không phát ra từ quan tài, mà chính là từ Muộn Du Bình vọng lại.

—————————————-

Chú thích

(1) Nguyên văn: Hỏa chiết tử. Bộ dụng cụ lấy lửa thời xưa gồm que đánh lửa, đá lửa và ống giữ lửa. Trong đó ống giữ lửa rất tiện dụng, là một ống đựng mồi lửa có thể đem theo bên mình, khi cần có thể rút ra châm lửa hoặc dùng thay cho đuốc thắp sáng. Phương pháp làm ống giữ lửa là lấy dây khoai trắng hoặc tím ngâm trong nước cho nở, vớt ra đập dập, lại ngâm chung thêm với bông vải, bông lau vớt ra đập dập, phơi khô, trộn thêm các loại vật liệu dễ cháy như kali, lưu huỳnh, nhựa thông, long não chế thành. Xong xuôi bện lại thành dây thừng hoặc buộc thành hình ống dài nén vào ống trúc, châm lửa cho cháy ngún rồi đậy kín lại, lúc cần dùng rút nắp ra là cháy, rất dễ cháy, là loại vua chúa hoặc nhà có tiền sử dụng. Nhà bình thường có thể dùng các loại giấy cắt thành dạng dài hơn ống trúc, cuộn đều tay, nhét vào trong ống. Sau đó châm lửa, rồi đậy nắp thông gió lại, tàn lửa sẽ được giữ trong ống. Lúc cần dùng bật nắp, thổi nhè nhẹ để lửa cháy lên, khi thổi cần phải có kỹ thuật thì lửa mới cháy lên được.

Đây là mô tả trên baidu, tả ống giữ lửa thời phong kiến, mình nghĩ loại dùng trong truyện là loại có tẩm vật liệu dễ cháy, chỉ cần rút nắp ra để tàn lửa âm ỉ trong ống tiếp xúc với oxy là lửa sẽ lập tức bùng lên.

Hình:

(1) Trường minh đăng:

长明灯

Đèn thắp để thờ cúng, là loại đèn không thể thổi tắt mà qua một thời gian sẽ tự tắt, còn có tên khác là Minh đăng, hoặc Vô tận đăng. Lăng mộ vua chúa Trung Hoa cũng đặt Trường minh đăng với hi vọng lăng mộ sáng tỏ huy hoàng như cung điện lúc sinh thời
 lăng mộ sáng tỏ huy hoàng như cung điện lúc sinh thời
